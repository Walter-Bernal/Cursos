# 5_ Text Mining

## 1_ Corpus

## 2_ Named Entity Recognition

## 3_ Text Analysis

## 4_ UIMA

## 5_ Term Document matrix

## 6_ Term frequency and Weight

## 7_ Support Vector Machines (SVM)

## 8_ Association rules

## 9_ Market based analysis

## 10_ Feature extraction

## 11_ Using mahout

## 12_ Using Weka

## 13_ Using NLTK

## 14_ Classify text

## 15_ Vocabulary mapping
