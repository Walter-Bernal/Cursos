# 9_ Data Munging

## 1_ Dim. and num. reduction

## 2_ Normalization

## 3_ Data scrubbing

## 4_ Handling missing Values

## 5_ Unbiased estimators

## 6_ Binning Sparse Values

## 7_ Feature extraction

## 8_ Denoising

## 9_ Sampling

## 10_ Stratified sampling

## 11_ PCA
