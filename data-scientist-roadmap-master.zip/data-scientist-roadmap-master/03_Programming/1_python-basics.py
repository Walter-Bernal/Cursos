#!/usr/bin/python3

''' 1_ Python basics '''

# Print something 
print('Hello, world')

# Assign a variable
a = 23
b = 'Hi guys, i\'m a text variable'
print('This is my variable: {}'.format(b))

# Mathematics
c = (a + 2) * (245 / 23)
print('This is mathe-magic: {}'.format(c))

